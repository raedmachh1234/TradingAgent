# Bubble Detection Quick Reference

## Daily Checklist (Complete in 5 Minutes)

### Morning Routine (Before Market Open)

```
□ Step 1: Update Bubble-O-Meter (2 minutes)
   - Score 6 quantitative indicators (0-2) + 3 qualitative adjustments (0-1)
   - Confirm risk budget based on the 0-15 total score

□ Step 2: Position Management (2 minutes)
   - Update ATR trailing stops
   - Check if stair-step profit-taking targets reached
   - Determine new entry eligibility

□ Step 3: Signal Confirmation (1 minute)
   - Media/social media trends (Google Trends, Twitter)
   - Major indices' distance from 52-week highs
   - VIX & Put/Call ratio
```

---

## Emergency Assessment: 3 Questions

Use these questions to flag concerns that need a full evaluation:

### Q1: "Are non-investors recommending it?"
- YES → Record specific, independent recommendations for verification
- NO → No social-penetration concern identified by this question

### Q2: "Has the narrative become 'common sense'?"
- YES → Record examples of consensus and treatment of dissent for verification
- NO → No consensus concern identified by this question

### Q3: "Is 'this time is different' the catchphrase?"
- YES → Record specific media examples for verification
- NO → No narrative concern identified by this question

**All 3 YES → Strong warning signal: run the full quantitative evaluation before acting.**

YES/NO answers alone establish neither a phase nor an action, including when all
answers are NO. Complete Phase 1 data collection and Phase 2 quantitative scoring,
then apply Phase 3 evidence-based adjustments under the strict criteria in
`../SKILL.md`. Use the final score for the phase and action matrix below;
Critical requires a final score of 13-15. If required data are missing, leave the assessment incomplete
and request the missing inputs instead of assigning a phase or action.

---

## Action Matrix by Bubble Stage (REVISED v2.1)

| Phase | Score | Risk Budget | Entry | Profit-Taking | Stop | Shorts |
|-------|-------|------------|-------|--------------|------|--------|
| **Normal** | 0-4 | 100% | Normal | At target | 2.0 ATR | No |
| **Caution** | 5-7 | 70-80% | 50% reduced | 25% at +20% | 1.8 ATR | No |
| **Elevated Risk** | 8-9 | 50-70% | Selective | 40% at +20% | 1.6 ATR | Consider |
| **Euphoria** | 10-12 | 40-50% | Stop | 50% at +20% | 1.5 ATR | After conditions |
| **Critical** | 13-15 | 20-30% | Stop | 75-100% immediate | 1.2 ATR | Recommended |

**Note**: Maximum score reduced from 16 to 15 points (Phase 2: max 12, Phase 3: max 3)

---

## v2.1 Quick Scoring: 6 Quantitative + 3 Qualitative

### Quantitative Indicators (0-2 each)

### 1. Put/Call Ratio
```
0 points: P/C > 0.85
1 point: P/C 0.70-0.85
2 points: P/C < 0.70
```

### 2. Volatility Suppression + New Highs
```
0 points: VIX > 15 or index more than 10% from highs
1 point: VIX 12-15 and index near highs
2 points: VIX < 12 and major index within 5% of 52-week high
```

### 3. Leverage
```
0 points: Margin debt YoY <= +10% or negative
1 point: Margin debt YoY +10-20%
2 points: Margin debt YoY +20% or more and all-time high
```

### 4. IPO Market Overheating
```
0 points: Normal levels
1 point: Quarterly IPO count >1.5x five-year average
2 points: Quarterly IPO count >2x five-year average and median first-day return +20%+
```

### 5. Breadth Anomaly
```
0 points: >60% of S&P 500 stocks above 50DMA
1 point: 45-60% above 50DMA
2 points: New high and <45% above 50DMA
```

### 6. Price Acceleration
```
0 points: Past 3-month return below 85th percentile
1 point: Past 3-month return in 85-95th percentile
2 points: Past 3-month return above 95th percentile
```

### Qualitative Adjustments (0-1 each; +3 max)

### A. Social Penetration
```
0 points: Any required evidence missing
1 point: Direct user report + specific examples + at least 3 independent sources
```

### B. Media/Search Trends
```
0 points: Search trends <5x or no mainstream coverage confirmation
1 point: Google Trends 5x+ YoY and mainstream coverage confirmed
```

### C. Valuation Disconnect
```
0 points: P/E <25 or fundamentals support valuation
1 point: P/E >25, fundamentals ignored, and "this time is different" documented
```

---

## Key Data Sources

### Instantly Checkable Indicators

| Indicator | Source | Example URL |
|-----------|--------|------------|
| Google Search Trends | Google Trends | trends.google.com |
| VIX (Fear Index) | CBOE | cboe.com/vix |
| Put/Call Ratio | CBOE | cboe.com/data |
| Margin Balance | FINRA | finra.org/data |
| Futures Positions | CFTC COT | cftc.gov/reports |
| IPO Statistics | Renaissance IPO | renaissancecapital.com |

### API-Accessible Auto-Retrieval

```python
# Example: Google Trends (pytrends)
from pytrends.request import TrendReq
pytrends = TrendReq()
pytrends.build_payload(['SPY', 'stock market'])
data = pytrends.interest_over_time()

# Example: VIX (yfinance)
import yfinance as yf
vix = yf.Ticker('^VIX')
current_vix = vix.history(period='1d')['Close'].iloc[-1]
```

---

## Profit-Taking Strategy Templates

### Template 1: Stair-Step Profit-Taking (Conservative)

```
Position: $10,000 initial investment
Targets:  +20%, +40%, +60%, +80%

+20% ($12,000) → Sell 25% = $3,000 secured
+40% ($14,000) → Sell 25% = $3,500 secured
+60% ($16,000) → Sell 25% = $4,000 secured
+80% ($18,000) → Sell 25% = $4,500 secured

Total profits: $15,000 (+50% equivalent)
```

### Template 2: ATR Trailing (Aggressive)

```python
def calculate_trailing_stop(current_price, atr_20d, bubble_phase):
    """
    Calculate trailing stop based on bubble stage

    bubble_phase: 'normal', 'caution', 'elevated_risk', 'euphoria', 'critical'
    """
    multipliers = {
        'normal': 2.0,
        'caution': 1.8,
        'elevated_risk': 1.6,
        'euphoria': 1.5,
        'critical': 1.2
    }
    multiplier = multipliers.get(bubble_phase, 2.0)
    stop_price = current_price - (atr_20d * multiplier)
    return stop_price

# Usage example
current_price = 450.0
atr_20d = 10.0  # Average True Range over 20 days
bubble_phase = 'euphoria'

stop = calculate_trailing_stop(current_price, atr_20d, bubble_phase)
print(f"Trailing Stop: ${stop:.2f}")
# Output: Trailing Stop: $435.00
```

### Template 3: Hybrid (Recommended)

```
Stage 1 (Boom period):
  → Reduce 50% of position via stair-step profit-taking

Stage 2 (Euphoria period):
  → Apply ATR trailing to remaining 50%, follow upside

Stage 3 (Panic signs):
  → Exit immediately when ATR stop hit
```

---

## Short-Selling Timing Assessment (Critical)

### ❌ Absolutely NG: Early Contrarian

```
Reason: Normal for prices to rise 2-3x more after feeling "too high"
Risk: "Markets can remain irrational longer than you can remain solvent"
```

### ✅ Recommended: After Composite Conditions Clear

**Consider starting when at least 3 apply:**

1. □ Weekly chart shows clear lower highs
2. □ Volume peaks out (3 consecutive weeks declining)
3. □ Sharp drop in leverage indicators (margin balance -20%+)
4. □ Media/search trends peak out
5. □ Weak stocks within sector start breaking down first
6. □ VIX surges (+30%+)
7. □ Fed/policy shift signals

**Execution Example:**

```
Condition Check:
[✓] 1. Weekly lower highs forming
[✓] 2. Volume declining 3 weeks straight
[×] 3. Margin balance still elevated
[✓] 4. Google search trends -40%
[×] 5. Still broad rally continuing
[✓] 6. VIX +35% surge
[×] 7. No policy changes

→ 4/7 met, shorts consideration OK
→ Small position (25% of normal) for test entry
```

---

## Common Failure Patterns & Solutions

### Failure 1: "Too late" paralysis, missing opportunities

**Psychology:** Regret aversion (fear of being late)
**Solution:**
- Conduct Bubble-O-Meter when feeling "too late"
- Score <=7: Small position entry OK
- Score 8-9: Only exceptional setups with reduced position size
- Score >=10: Correct to stay out

### Failure 2: Re-entry after profit-taking (buying high)

**Psychology:** Hindsight bias ("knew it would go higher")
**Solution:**
- 72-hour no re-entry rule after profit-taking
- Re-entry decisions only after Bubble-O-Meter check

### Failure 3: Can't take profits due to "still rising"

**Psychology:** Greed + Overconfidence
**Solution:**
- Automate stair-step profit-taking (pre-set limit orders)
- Aim for "satisfaction," abandon "perfection"

### Failure 4: Too-early shorts

**Psychology:** Subjective "obviously too high" judgment
**Solution:**
- Mechanically verify composite conditions
- Wait for minimum 3 conditions to clear

---

## Emergency Response Flowchart

```
Detect market volatility
    ↓
Q: Have positions?
    ↓YES
Q: Down -5% or more?
    ↓YES
Q: ATR stop reached?
    ↓YES
→ Sell immediately (no debate)

    ↓NO (Stop not reached)
Q: Bubble-O-Meter score 13+?
    ↓YES
→ Consider 75%+ profit-taking

    ↓NO (Score ≤12)
Q: VIX surge +30%+?
    ↓YES
→ 50% profit-taking, tighten remaining stops

    ↓NO
→ Business as usual, continue calm observation
```

---

## Golden Rules (10 Commandments to Post on Wall)

1. **See process, not price**

2. **When taxi drivers talk stocks, run the full quantitative assessment**

3. **"This time is different" is always the same**

4. **Mechanical rules protect psychology**

5. **Short after confirmation, take profits early**

6. **When skepticism hurts, the end begins**

7. **Aim for satisfaction, abandon perfection**

8. **Bubbles last longer than expected, collapses are faster**

9. **Leverage is an express ticket to ruin**

10. **"Markets can remain irrational longer than you can remain solvent"**

---

## Resources for Further Learning

### Books
- **"Manias, Panics, and Crashes"** - Charles Kindleberger
- **"Irrational Exuberance"** - Robert Shiller
- **"The Alchemy of Finance"** - George Soros

### Research
- Hyman Minsky's Financial Instability Hypothesis
- Classic papers in Behavioral Finance

### Data & Tools
- **TradingView**: Charts and technical indicators
- **FRED (Federal Reserve)**: Economic indicator time series
- **Finviz**: Screening and heatmaps
- **Google Trends**: Social trends

---

**Last Updated:** 2025 Edition
**License:** Educational and personal use only, redistribution prohibited
