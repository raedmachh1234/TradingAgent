"""Make the skill's scripts/ importable for tests."""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
